
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include <sstream>


using namespace std;

//Creates the course
struct Course {
    string courseName;
    string courseNumber;
    vector<string> preReqs;
};

//Used for Tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    Node() {
        left = nullptr;
        right = nullptr;
    }

    Node(Course aCourse) : Node() {
        this->course = aCourse;
    }
};

//Defines a class containing data for a Binary Search Tree
class CourseBST {

private:
    void Destruct(Node* node);

public:
    Node* root;
    CourseBST();
    virtual ~CourseBST();
    void Insert(CourseBST* tree, Node* node);
    void Search(string courseNumber);
    void PrintCourse(Node* node);
};

//Default constructor
CourseBST::CourseBST() {
    root = nullptr;
}

//Destructor
CourseBST::~CourseBST() {
    Destruct(root);
};

void CourseBST::Destruct(Node* node) {
    if (node != nullptr) {
        Destruct(node->left);
        node->left = nullptr;
        Destruct(node->right);
        node->right = nullptr;
        delete node;
    }
};

//Searches for a course and prints output
void CourseBST::Search(string courseNumber) {
    Node* currentNode = root;

    while (currentNode != nullptr) {
        if (currentNode->course.courseNumber == courseNumber) {

            cout << currentNode->course.courseNumber << ", ";
            cout << currentNode->course.courseName;
            cout << endl;
            cout << "Prerequisites: ";

            for (string preRequisite : currentNode->course.preReqs) {
                if (preRequisite == currentNode->course.preReqs.back()) {

                    cout << preRequisite << endl;
                }
                else {
                    cout << preRequisite << ", ";
                }
            }

            return;
        }

        else if (courseNumber < currentNode->course.courseNumber) {

            if (currentNode->left != nullptr) {
                currentNode = currentNode->left;
            }
        }

        else {

            currentNode = currentNode->right;
        }
    }

    cout << "Course " << courseNumber << "not found. " << endl;
    return;
}

//Inserts course into a list
void CourseBST::Insert(CourseBST* tree, Node* node) {

    if (tree->root == nullptr) {
        tree->root = node;
    }
    else {
        Node* curr = tree->root;
        while (curr != nullptr) {

            if (node->course.courseNumber < curr->course.courseNumber) {
                if (curr->left == nullptr) {
                    curr->left = node;
                    curr = nullptr;
                }
                else {
                    curr = curr->left;
                }
            }
            else {

                if (curr->right == nullptr) {
                    curr->right = node;
                    curr = nullptr;
                }
                else {
                    curr = curr->right;
                }
            }

        }

    }
}

//Prints course list
void CourseBST::PrintCourse(Node* node) {


    if (node == nullptr) {
        return;
    }


    PrintCourse(node->left);
    cout << node->course.courseNumber << ", ";
    cout << node->course.courseName << endl;
    PrintCourse(node->right);
};

//loads file
void loadCourse(string filename, CourseBST* bst) {
    ifstream file(filename);
    if (file.is_open()) {
        cout << "File loaded." << endl;

        int num;
        string line;
        string word;

        while (getline(file, line)) {

            num = 0;
            Node* node = new Node();
            stringstream str(line);

            while (num < 2) {
                getline(str, word, ',');
                if (num == 0) {
                    node->course.courseNumber = word;
                }
                else {
                    node->course.courseName = word;
                }
                num++;
            }
            while (getline(str, word, ',')) {
                node->course.preReqs.push_back(word);
            }

            bst->Insert(bst, node);
        }
    }

    else {
        cout << "File error, please try again. " << endl;
        return;
    }

}

//Display for menu
void DisplayMenu() {
    cout << "1. Load Data Structure" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "9. Exit" << endl << endl;
    cout << "What would you like to do? ";
}

//Main method
void main() {

    CourseBST* bst = new CourseBST();

    string fin;
    string courseChoice;

    int userInput = 0;

    cout << "Welcome to the course planner." << endl << endl;

    while (userInput != 9) {
        DisplayMenu();
        cin >> userInput;

        switch (userInput) {

            //Loads file
        case 1:
            cout << endl;
            fin = "ABCUCourses.csv";
            loadCourse(fin, bst);
            cout << endl;
            break;

            //Prints courses
        case 2:
            cout << endl;
            cout << "Here is a sample schedule: " << endl << endl;
            bst->PrintCourse(bst->root);
            cout << endl;
            break;

            //Prints user chosen courses
        case 3:
            cout << endl;
            cout << "What course do you want to know about? ";
            cin >> courseChoice;
            cout << endl;

            std::transform(courseChoice.begin(), courseChoice.end(), courseChoice.begin(), ::toupper);
            bst->Search(courseChoice);

            cout << endl;
            break;

            //Exit
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            break;

        default:
            cout << userInput << " is not a valid option." << endl << endl;
            break;
        }
    }
}